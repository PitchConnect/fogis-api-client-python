"""
Fogis Session Tools

A collection of tools for managing persistent sessions with the Fogis API.
"""

__version__ = "0.1.0"
